package constant;

public enum LevelDriver {
    Loai_A("Loại A"),
    Loai_B("Loại B"),
    Loai_C("Loại C"),
    Loai_D("Loại D"),
    Loai_E("Loại E"),
    Loai_F("Loại F");
    public String value;
    LevelDriver(String value){ this.value =value;}

}
